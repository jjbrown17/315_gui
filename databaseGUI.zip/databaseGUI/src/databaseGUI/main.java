package databaseGUI;

public class main {
	public static void main(String[] args) {
		UI ui = new UI(800, 600);
	}
}