package databaseGUI;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.DefaultListSelectionModel;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.JToggleButton;
import javax.swing.WindowConstants;

public class UI implements Runnable{
	
	int WIDTH, HEIGHT;
	JFrame j;
	DefaultListSelectionModel toggleList; 
	
	public UI(int w, int h){
		WIDTH = w;
		HEIGHT = h;
		
		toggleList = new DefaultListSelectionModel(){

			@Override
	    	public void setSelectionInterval(int index0, int index1){
	    		if (super.isSelectedIndex(index0)) super.removeSelectionInterval(index0, index1);
	    		else super.addSelectionInterval(index0, index1);
	    	}
	    };
		
		run();
	}

	@Override
	public void run() {
		
		//Creating the panel at the top left
        JPanel panel = new JPanel(); 
        
        JLabel label = new JLabel("Enter Text Query:");
        JTextField tf = new JTextField(WIDTH/50); 
        
        final JToggleButton toggleButton = new JToggleButton("Output to File");    
        final JButton submit = new JButton("Submit");
        
        panel.add(label);//defaults to flowlayout
        panel.add(tf);
        panel.add(toggleButton);
        
        //needs to be moved below the other buttons
        panel.add(submit);
        
        JPanel panel2 = new JPanel(); 
        //This is where the radio button goes
        String[] tags = new String[]{"Name", "Movie"};
        JList<String> list = new JList<String>(tags);
        list.setSelectionModel(toggleList);
        
        JLabel label2 = new JLabel("Select one or more tags to search");
        
        panel2.add(label2);
        panel2.add(list);

		JFrame j = new JFrame("Database Proj");
        j.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        j.setPreferredSize(new Dimension(WIDTH, HEIGHT));      
        j.setResizable(false);
        j.pack();
        j.getContentPane().add(BorderLayout.WEST, panel);
        j.getContentPane().add(BorderLayout.EAST, panel2);
        j.setVisible(true);		

        submit.addActionListener(new ActionListener(){

            public void actionPerformed(ActionEvent e)
            {
                System.out.println("action");
                newQuery q = new newQuery(tf.getText(), list.getSelectedValuesList(), HEIGHT, WIDTH);
            }
        });
	}
}
