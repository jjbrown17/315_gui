package databaseGUI;

import java.util.List;

public class Person {
    private String name;
    private String born;
    private String died;
    private String[] knownFor;
    private List<String> works;
    Person(String _name, String _born, String _died, String[] _knownFor, List<String> _works){
        name = _name; born = _born; died = _died; 
        knownFor = _knownFor; works = _works;
    }
    public String getName(){
        return this.name;
    }
    public String getDateBorn(){
        return this.born;
    }
    public String getDateDied(){
        return this.died;
    }
    public String[] getKnownFor(){
        return this.knownFor;
    }
    public List<String> getWorks(){
        return this.works;
    }
 }
