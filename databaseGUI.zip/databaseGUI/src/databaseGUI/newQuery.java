package databaseGUI;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.LayoutManager;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.WindowConstants;

public class newQuery {
	List<String> tags;
	String query;
	int HEIGHT, WIDTH;

	newQuery(String _query, List<String> _tags, int h, int w) {
		tags = new ArrayList<String>();
		tags.addAll(_tags);
		query = _query;
		HEIGHT = h;
		WIDTH = w;

		action();
	}

	public void action() {
		for (String s : tags) {
			newPane(s, query);
		}
	}

	public void newPane(String group, String query) {
		// group is from radio button group
		if (group.equals("Name")) {
			Person person = QueryToPerson(query);
			// instantiate a PersonView using the person
			// JFrame j = new JFrame();
			JPanel panel = new JPanel();

			final JButton exit = new JButton("Exit");

			// needs to be moved below the other buttons
			String information = personFormat(person);
			JLabel info = new JLabel(information);

			panel.add(info);
			panel.add(exit);

			JFrame j = new JFrame("Search Results For: " + group);

			j.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
			j.setPreferredSize(new Dimension(WIDTH / 3, HEIGHT / 3));
			j.setResizable(false);
			j.pack();
			j.getContentPane().add(BorderLayout.WEST, panel);
			j.setVisible(true);
		}
	}

	public String personFormat(Person person) {
		String name = "Name: " + person.getName() + "<br/>";
		String born = "Born: " + person.getDateBorn() + "<br/>";
		String died = "Died: " + person.getDateDied() + "<br/>";
		String known = "";

		for (String s : person.getKnownFor()) {
			known += s + " ";
		}

		return "<html>" + name + born + died + known + "</html>";
	}

	public Person QueryToPerson(String query) {
		// interface with PostgreSQL DB name_basics table with query as key
		// convert row returned into the data members of person
		// row is mocked and would be from the db
		String[] row = { "Fred Astaire", "1859", "1907", "[Actor, Soundtrack]", "[t013219321, t3249303, t31243432]" };
		String personName = row[0];
		String personBorn = row[1];
		String personDied = "";
		if (!row[2].isEmpty()) {
			personDied = row[2];
		}
		String known = row[3].substring(1, row[3].length() - 1);
		String[] knownArray = known.split(",");

		String[] tconstQueries = row[3].substring(1, row[3].length() - 1).split(",");
		List<String> titles = new ArrayList();
		for (String tconstQuery : tconstQueries) {
			// interface with db using tconstQuery as key in the table title_akas. Return
			// titlename attribute from row with titleid == tconst
			String titleNameFromDB = "Gone With The Wind";
			titles.add(titleNameFromDB);
		}
		return new Person(personName, personBorn, personDied, knownArray, titles);
	}
}
