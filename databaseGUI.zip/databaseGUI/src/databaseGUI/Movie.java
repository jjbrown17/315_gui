package databaseGUI;

public class Movie {

}
